class Page(object):
    header = """<!DOCTYPE>
<html>
    <head>
        <link rel="stylesheet" href="styles/style.css" type="text/css"/>
        <title> Debt calculator </title>
    </head>
    <body>

        <h1> Debt calculator </h1>
        <p> Everyone goes to school for a better life but we all know when you go as a full time student to where\
        you cannot work you will acquire a lot of debt here I will show you how much debt a few students are and \
        what degrees they were in when they graduated </p>

        <h3> (ex)-Students </h3>

        <a href="#"> person1 </a>
        <a href="#"> person2 </a>
        <a href="#"> person3 </a>
        <a href="#"> person4 </a>
        <a href="#"> person5 </a>

    </body>
 </html>"""
